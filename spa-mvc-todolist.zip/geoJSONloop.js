for (var j = 0; j < obj3.length; j++) {
    for (var k = 0; k < obj3[j].geometry.coordinates[0].length; k++) {
        coordinates.push( [[ "feature", j ], [ obj3[j].geometry.coordinates[0][k][0] , obj3[j].geometry.coordinates[0][k][1] ] ] );
        console.log(obj3[j].geometry.coordinates[0].length - 1);
        console.log(k);
        console.log("booya");
        polygon0 = `${polygon0}
        [${obj3[j].geometry.coordinates[0][k]}],`;

        if ( (obj3[j].geometry.coordinates[0].length - 1)  === k  ) {

            console.log("supaa");

            polygon0 = "[" + polygon0 + "]" ;
            console.log(polygon0);
            polygon01 = L.polygon(  polygon0  );
            //console.table(polygon01);
                //		polyLayers.push(polygon01);
            polygon0 = "";
        }
        
    }
}