import { BasicElement } from './BasicElement.js';

export class Button extends BasicElement {
	constructor(title, classes) {
		super('button', classes);

		this.element.textContent = title;
	}
}
