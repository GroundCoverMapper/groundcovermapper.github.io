import { BasicElement } from './BasicElement.js';

export class Title extends BasicElement {
	constructor(title, classes) {
		super('h2', classes);
		this.element.textContent = title;
	}
}
