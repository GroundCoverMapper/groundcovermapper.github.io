export class BasicElement {
	constructor(tag, classes = [], names ) {
		this.element = document.createElement(tag);
		this.element.classList.add(...classes);

	}
}
