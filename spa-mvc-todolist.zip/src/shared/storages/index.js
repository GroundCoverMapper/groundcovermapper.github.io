import { LOCAL_STORAGE, SESSION_STORAGE } from '../constants.js';
import { LocalStorage } from './LocalStorage.js';
import { SessionStorage } from './SessionStorage.js';

export const Store = {
	[LOCAL_STORAGE]: LocalStorage,
	[SESSION_STORAGE]: SessionStorage,
};
