export const LOCAL_STORAGE = 'LOCAL_STORAGE';
export const SESSION_STORAGE = 'SESSION_STORAGE';

export const STORAGES = [LOCAL_STORAGE, SESSION_STORAGE];

export const BTN_SWITCH_STORE_TITLE = {
	[LOCAL_STORAGE]: 'Ground Cover Mapper',
	[SESSION_STORAGE]: 'Ground Cover Mapper',
};

export const CURRENT_STORE_TITLE = {
	[LOCAL_STORAGE]: 'Permanent - Local Storage',
	[SESSION_STORAGE]: 'Temporary - Session Storage',
};

export const PAGES = [
	{ title: 'Observations', owner: 'my' },
	{ title: 'Transects', owner: 'dad' },
	{ title: 'Polygons', owner: 'mom' },
];
