function polylineIntersections() {


    console.log("mooji say hello");

}