import { BasicElement } from '../shared/ui/index.js';

export class TodoList extends BasicElement {
	constructor() {
		super('ul', ['list-group']);
	}
}
