 
 		const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVqZnR6eWh1ZGJyZmZycXF3a25lIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NDk4ODU2OTAsImV4cCI6MTk2NTQ2MTY5MH0.RkyjZEJwYXA48DKeZQafMk9K4QgCKinxZvrpBDF4SVM"
         const supabaseUrl = "https://ujftzyhudbrffrqqwkne.supabase.co"
      
         const _supabase = supabase.createClient(supabaseUrl, supabaseAnonKey);
 
         const random = (length = 8) => {
             // Declare all characters
             let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
         
             // Pick characers randomly
             let str = '';
             for (let i = 0; i < length; i++) {
                 str += chars.charAt(Math.floor(Math.random() * chars.length));
             }
         
             return str;
         
         };
  
         if (localStorage.getItem("user") == null) {
             localStorage.setItem('user', random(20));
              console.log(" user initialized ");
         }
 
         var osmUrl = 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
             osmAttrib = '&copy; <a href="http://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
             osm = L.tileLayer(osmUrl, {maxZoom: 24, attribution: osmAttrib}),
             map = new L.Map('map', {layers: [osm], center: new L.LatLng(51.509, -0.08), zoom: 14 });
 
         var drawnItems = new L.FeatureGroup();
         map.addLayer(drawnItems);
 
 
 
         async function loadData() {
             const { data, error } = await _supabase
                     .from('leafletjson')
                     .select('json')  
                     .filter('id','in','(14)') 
                     ;
 
             console.log("via supa");
             
             console.log(error);
             var obj = JSON.parse(JSON.stringify( data ));
             console.log(obj);
 
 
 
             console.log("via supa2");
             var obj2 = JSON.parse(obj[0]['json']);
 
             localStorage.setItem('loadedFeaturesViaRemote', JSON.stringify(obj2.features));
 
 
             //			console.log(obj[0]['json']);
             console.log('ojb2');
             console.log(obj2.features);
 
             var polyLayers = [];
             var polygonCoords = [];
             var coordinates = [];
             var polygon = [];
 
             var obj2 = JSON.parse(obj[0]['json']);

             var latlngs = obj2.features;
             for (var i = 0; i < latlngs.length; i++) {
                 coordinates.push([latlngs[i].geometry.coordinates[0][0]])
                 //L.polygon([latlngs[i].geometry.coordinates[0][0]])
                 console.log("via supa2a");
                 console.log( latlngs[i].geometry.coordinates[0][0] );
                 console.log("via supa2b");
                 polygonCoords += ("[" + [latlngs[i].geometry.coordinates[0][0]] + "],");
 
             }
             //geojson['geometry']['coordinates'] = [coordinates];
              

             //			var returnedGeojson = [{  "type": "FeatureCollection",  "features": [    {      "type": "Feature",      "properties": {},      "geometry": {        "type": "Polygon",        "coordinates": [          [            [              -0.08,              51.509            ],            [              -0.06,              51.503            ],            [              -0.047,              51.51            ],            [              -0.08,              51.509            ]          ]        ]      }    },    {      "type": "Feature",      "properties": {},      "geometry": {        "type": "Polygon",        "coordinates": [          [            [              -0.099993,              51.512642            ],            [              -0.087633,              51.520387            ],            [              -0.082483,              51.509116            ],            [              -0.099993,              51.512642            ]          ]        ]      }    },    {      "type": "Feature",      "properties": {},      "geometry": {        "type": "Polygon",        "coordinates": [          [            [              -0.08754730224609376,              51.50852877586289            ],            [              -0.08754730224609376,              51.50852877586289            ],            [              -0.09518623352050783,              51.50623162095866            ],            [              -0.09518623352050783,              51.50623162095866            ],            [              -0.08368492126464844,              51.50436175821088            ],            [              -0.08368492126464844,              51.50436175821088            ],            [              -0.08205413818359376,              51.50612477372582            ],            [              -0.08205413818359376,              51.50612477372582            ],            [              -0.08394241333007814,              51.5081548283056            ],            [              -0.08394241333007814,              51.5081548283056            ],            [              -0.08754730224609376,              51.50852877586289            ]          ]        ]      }    }  ]}];
			var returnedGeojson = '{  "type": "geojson",  "data": [    {      "type": "Feature",      "properties": {},      "geometry": {        "type": "Polygon",        "coordinates": [          [            [              -0.08,              51.509            ],            [              -0.06,              51.503            ],            [              -0.047,              51.51            ],            [              -0.08,              51.509            ]          ]        ]      }    },    {      "type": "Feature",      "properties": {},      "geometry": {        "type": "Polygon",        "coordinates": [          [            [              -0.099993,              51.512642            ],            [              -0.087633,              51.520387            ],            [              -0.082483,              51.509116            ],            [              -0.099993,              51.512642            ]          ]        ]      }    },    {      "type": "Feature",      "properties": {},      "geometry": {        "type": "Polygon",        "coordinates": [          [            [              -0.08754730224609376,              51.50852877586289            ],            [              -0.08754730224609376,              51.50852877586289            ],            [              -0.09518623352050783,              51.50623162095866            ],            [              -0.09518623352050783,              51.50623162095866            ],            [              -0.08368492126464844,              51.50436175821088            ],            [              -0.08368492126464844,              51.50436175821088            ],            [              -0.08205413818359376,              51.50612477372582            ],            [              -0.08205413818359376,              51.50612477372582            ],            [              -0.08394241333007814,              51.5081548283056            ],            [              -0.08394241333007814,              51.5081548283056            ],            [              -0.08754730224609376,              51.50852877586289            ]          ]        ]      }    }  ]}';

 




		/*
		//			drawnItems.addMarker(layer);
		//		for(layer of markerLayers) {
		//		}
		//		if (markerLayers){
		//		for(layer of markerLayers) {
		//			L.marker(layer).addTo(drawnItems);
		//			alert(obj.data)
		//			L.marker([layer]).addTo(map);
		//			drawnItems.addLayer([layer]);
		//		}
		//	}
		

		// Add the layers to the drawnItems feature group 
		for(layer of polyLayers) {
			console.log("loopio")
			drawnItems.addLayer(layer);
		}
		*/



         /*	console.log("via supa2c");
             console.log(polygonCoords);
             polygon = L.polygon([polygonCoords]);
             polyLayers.push(polygon);
             var layer = [];
 
             console.log("via supa2d1");
 
             localStorage.setItem('polyLayers', polygonCoords);
 
 
             // Add the layers to the drawnItems feature group 
               for(layer of polyLayers) {
                 console.log("via supa2d");
                 drawnItems.addLayer(layer);
             }*/
 
             }
             loadData();
 
             var polyLayers = [];
 
         
             var polygon1 = L.polygon([
                 [51.509, -0.08],
                 [51.503, -0.06],
                 [51.51, -0.047]
             ]);
     
             polyLayers.push(polygon1)
     
             var polygon2 = L.polygon([
                 [51.512642, -0.099993],
                 [51.520387, -0.087633],
                 [51.509116, -0.082483],
             ]);
             polyLayers.push(polygon2)
 
     
 
             var datalocal = localStorage.getItem("loadedFeaturesViaRemote");
 
 
             var obj3 = JSON.parse(datalocal);
             console.log("foo");
 
             console.log(obj3[0]);
             console.log(obj3.length);
 
 
             console.log("obj33333")
 
 //			[i].geometry.coordinates[0][0]
 
             var coordinates = [];
             for (var j = 0; j < obj3.length; j++) {
                 console.log("obj3333456");
                  for (var k = 0; k < obj3[j].geometry.coordinates[0].length; k++) {
                     coordinates.push( [[ "feature", j ], [ obj3[j].geometry.coordinates[0][k][0] , obj3[j].geometry.coordinates[0][k][1] ] ] );
 
                  }
 //				coordinates.push([obj3[j]]);
                 console.log("obj3333456");
 
             }
 
             console.log("coordinates");
  
             console.log(coordinates);
  
             var layer = [];
             // Add the layers to the drawnItems feature group 
             for(layer of polyLayers) {
                 drawnItems.addLayer(layer);
             }
     
 
 
         // Set the title to show on the polygon button
         L.drawLocal.draw.toolbar.buttons.polygon = 'Create a polygon';
 
         var drawControl = new L.Control.Draw({
             position: 'bottomleft',
             draw: {
                 polyline: {
                     metric: true
                 },
                 polygon: {
                     allowIntersection: false,
                     showArea: true,
                     drawError: {
                         color: '#b00b00',
                         timeout: 1000
                     },
                     shapeOptions: {
                         color: '#bada55'
                     }
                 },
                 circle: {
                     shapeOptions: {
                         color: '#662d91'
                     }
                 },
                 marker: true
             },
             edit: {
                 featureGroup: drawnItems,
                 remove: true
             }
         });
         map.addControl(drawControl);
 
         var locator = L.control.locate({
             position: 'bottomleft',
             strings: {
             title: "Show your current position"
             }
         }).addTo(map);
 
         map.on('draw:created', function (e) {
             var type = e.layerType,
                 layer = e.layer;
 
             if (type === 'marker') {
                 layer.bindPopup('A popup!');
             }
 
 
 
             var featureGroup = L.featureGroup().addTo(map);
             var coords = e.layer._latlng;
             console.log(coords);
             var tempMarker = featureGroup.addLayer(e.layer);
             var popupContent = '<form role="form" id="markerform" enctype="multipart/form-data" action="#" class = "form-horizontal" onsubmit="addMarker()">'+
             
             '<div class="form-group">'+
                 '<label class="control-label col-sm-5"><strong>Density: </strong></label>'+
                 '<select class="form-control" id="density" name="density">'+
                 '<option value="Vhigh">Very High</option>'+
                 '<option value="High">High</option>'+
                 '<option value="MedHigh">Med High</option>'+
                 '<option value="Medium">Medium</option>'+
                 '<option value="LowMed">Low-Med</option>'+
                 '<option value="Low">Lowe</option>'+
                 '<option value="None">None</option>'+
                 '</select>'+ 
             '</div>'+
             '<div class="form-group">'+
                 '<label class="control-label col-sm-5"><strong>Density: </strong></label>'+
                 '<input type="number" min="0" max="10" class="form-control" id="numden" name="numden">'+ 
             '</div>'+
             //...
             '<div class="form-group">'+
                 '<label class="control-label col-sm-5"><strong>Description: </strong></label>'+
                 '<textarea class="form-control" rows="6" id="descrip" name="descript">...</textarea>'+
             '</div>'+
             '<div class="form-group">'+
               '<div style="text-align:center;" class="col-xs-4"><button type="button" class="btn">Cancel</button><button type="submit" value="submit" class="btn btn-primary trigger-submit">Submit</button></div>'+
             '</div>'+
             '</form>';
             tempMarker.bindPopup(popupContent,{
               keepInView: true,
               closeButton: false
               }).openPopup();
   
 
 
             if (type === 'polygon') {
                 
                 // structure the geojson object
                 var geojson = {};
                 geojson['type'] = 'Feature';
                 geojson['geometry'] = {};
                 geojson['geometry']['type'] = "Polygon";
         
                 // export the coordinates from the layer
                 var coordinates = [];
                 var latlngs = layer.getLatLngs();
                 for (var i = 0; i < latlngs.length; i++) {
                     coordinates.push([latlngs[i].lng, latlngs[i].lat])
                 }
         
                 // push the coordinates to the json geometry
                 geojson['geometry']['coordinates'] = [coordinates];
         
                 // Finally, show the poly as a geojson object in the console
                 console.log(JSON.stringify(geojson));
         
                    }
 
             drawnItems.addLayer(layer);
         });
 
         map.on('draw:edited', function (e) {
             var layers = e.layers;
             var countOfEditedLayers = 0;
             layers.eachLayer(function(layer) {
                 countOfEditedLayers++;
             });
             console.log("Edited " + countOfEditedLayers + " layers");
         });
 
 
     /*	async function loadData() {
             const { data, error } = await _supabase
                     .from('leafletjson')
                     .select('json')  
                     .filter('id','in','(14)') 
                     ;
         
             console.log("via supa");
             
             console.log(error);
             var obj = JSON.parse(JSON.stringify( data ));
             console.log(obj);
             console.log("via supa2");
             var obj2 = JSON.parse(obj[0]['json']);
 
 //			console.log(obj[0]['json']);
             console.log('ojb2');
             console.log(obj2.features);
 
             
             var coordinates = [];
             var polygon = [];
             var latlngs = obj2.features;
             for (var i = 0; i < latlngs.length; i++) {
                 coordinates.push([latlngs[i].geometry.coordinates[0][0]])
                 //L.polygon([latlngs[i].geometry.coordinates[0][0]])
 
                 polygon = L.polygon([latlngs[i].geometry.coordinates[0][0]])
 
             }
             //geojson['geometry']['coordinates'] = [coordinates];
         
             polyLayers.push(polygon);
 
             var layer = [];
             // Add the layers to the drawnItems feature group 
             for(layer of polyLayers) {
                 drawnItems.addLayer(layer);
             }
     /*
     var polygon2 = L.polygon([
             [51.512642, -0.099993],
             [51.520387, -0.087633],
             [51.509116, -0.082483]
         ]);
         polyLayers.push(polygon2)
 
     */
     
 
 
             // Finally, show the poly as a geojson object in the console
             //console.log(JSON.stringify(geojson));
 //			console.log('coordinates');
 //			console.log(coordinates);
 
             /*
             var polygon2 = L.polygon([
                 [51.512642, -0.099993],
                 [51.520387, -0.087633],
                 [51.509116, -0.082483]
             ]);
             polyLayers.push(polygon2)
 
 
             
         //	drawnItems.addLayer(coordinates);
              
  
         }
         loadData();
         */
 
 // Null variable that will hold layer
 
 
 //Add layer control
 //L.control.layers(baseMaps, overlayMaps).addTo(map);
 
 
         var logo = L.control({position: 'bottomright'});
         logo.onAdd = function(map){
             var div = L.DomUtil.create('div', 'myclass');
             div.innerHTML= "<img src='/icons/gcm_logo_april30_2022.svg' height=70 />";
             return div;
         }
         logo.addTo(map);
 
 
 
         document.getElementById("convert").addEventListener("click", function () {
             console.log(JSON.stringify(drawnItems.toGeoJSON(), null, 2));
 
             /**  write geojson polygon data to todo storage 
             document.getElementsByClassName("form-control").value( "polyLayers", JSON.stringify(drawnItems.toGeoJSON(), null, 2) ) 
             const newItem = { ...todo, id: Date.now().toString(16) };
             */
 
             localStorage.setItem("user", JSON.stringify(drawnItems.toGeoJSON(), null, 2) );
 
 
             async function insertData() {
                 const { data, error } = await _supabase
                     .from('leafletjson')
                       .insert([
                         { json:  JSON.stringify(drawnItems.toGeoJSON(), null, 2) }
                     ]);
             
                 console.log(data);
                 console.log(error);
             }
             insertData();
 
 
 
 });