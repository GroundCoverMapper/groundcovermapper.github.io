import Model from '/src/core/Model.js';
import View from '/src/core/View.js';
import Controller from '/src/core/Controller.js';



const root = document.getElementById('todo-app');

const view = new View(root);
const model = new Model();

new Controller(view, model);
