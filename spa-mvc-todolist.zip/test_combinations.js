// load basemap
// load objects from memory


//source object_arr = ['polyline321','polyline453','polyline532']

/*
var normal = L.layerGroup();

var baseLayers = {
                 "Map": Normal,
}

var overlayLayers = {
                 "Figure": Normal,
}

var map = L.map("map", {
    center: [51.50514, -0.12943],
    zoom: 12,
    layers: [normal],
    zoomControl: true

});
*/

console.log(turf.greatCircle([0, 0], [100, 10]));

var osmUrl = 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
osmAttrib = '&copy; <a href="http://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
osm = L.tileLayer(osmUrl, {maxZoom: 24, attribution: osmAttrib}),
map = new L.Map('map', {layers: [osm], center: new L.LatLng(-33.553984,-70.823364), zoom: 14 });

/*
var extent = [-70.823364, -33.553984, -70.473175, -33.302986];
var cellSide = 3;
var options = {units: 'miles'};

var grid = turf.pointGrid(extent, cellSide, options);

//addToMap
//var addToMap = [grid];
map.addLayer(grid);
*/



var drawnItems = new L.FeatureGroup();
map.addLayer(drawnItems);
// map.fitBounds(polyline.getBounds());


if (localStorage.getItem("leafletFeatureIndex") !== null) {
    var featureindex = localStorage.getItem("leafletFeatureIndex");
    const newArr = featureindex.split(',');
    var polylines = []

    newArr.forEach(element => {
        const loopi = localStorage.getItem(element);
        const obj = JSON.parse(loopi)
           
        if (obj.featuretype[0] === "polyline") {
            console.log(element)
            // build polyine collection
            //if (polylines !== [])  
            polylines = polylines + "," + element        
        }

    });   
}

polylines = polylines.substring(1)
console.log(polylines)
const polyarra = polylines.split(',');

const combinations = ([head, ...tail]) => tail.length > 0 ? [...tail.map(tailValue => [head, tailValue]), ...combinations(tail)] : []
console.log(combinations(polyarra)) //[ [ 'a', 'b' ], [ 'a', 'c' ], [ 'b', 'c' ] ]

//  compare duals to see if polygons intersect

console.log(  "n" )


var intersects2 = [51.49937,-0.12068]

//console.log(transpose(JSON.parse(intersects2)))

console.log(  "n" )



var n =0;
combinations(polyarra).forEach(element2 => {

 n = n+1
 console.log(  n )

 var feature1 = localStorage.getItem(element2[0]);
 var feature2 = localStorage.getItem(element2[1]);


 //console.log(JSON.stringify(JSON.parse(feature1).data))
 //console.log(JSON.stringify(JSON.parse(feature2).data))

 feature1 = JSON.stringify(JSON.parse(feature1).data)
 console.log(feature1)

 feature2 = JSON.stringify(JSON.parse(feature2).data)
 console.log(feature2)

// feature1[0].map((_, colIndex) => feature1.map(row => row[colIndex]))

// feature2[0].map((_, colIndex) => feature2.map(row => row[colIndex]))



 var feature1a = turf.lineString(feature1, {name: 'feature 1'})
 var feature2a = turf.lineString(feature2, {name: 'feature 2'})


 console.log(turf.greatCircle(feature1a, feature2a));


 var intersects = turf.lineIntersect(feature1a, feature2a);
 console.log(intersects)


})




// Functions
//
//
function transpose(matrix) {
    return matrix[0].map((col, c) => matrix.map((row, r) => matrix[r][c]));
  }
